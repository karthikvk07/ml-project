Marine Engine Fault Dataset — cleaned causal preprocessing export
Source: Marine_Engine_Fault_Data_v1.zip
Cleaning: temperature columns only; values >800°C or <-20°C converted to NaN.
Short missing runs: causal forward fill, maximum 10 consecutive rows (pandas ffill(limit=10)).
Long gaps: not interpolated; values beyond first 10 missing rows remain NaN.
Original files are unchanged. Metadata/unit rows are omitted; column headers and data are retained.
Reference_Data.csv is included separately and has no anomaly label.
This export does not apply scaling, feature selection, or model fitting.
